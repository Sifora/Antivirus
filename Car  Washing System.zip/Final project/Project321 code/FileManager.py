import tkinter as tk
from tkinter import messagebox
import random
global window


class products():
    def __init__(self):
        self.productid=""
        self.productname=""
        self.productprice=0
    def setproductid(self ,id=0):
        self.productid = id
    def getproductid(self):
        return  self.productid
    def setproductname(self,name=""):
        self.productname = name
    def getproductname(self):
        return  self.productname
    def setproductprice(self,price=0):
        self.productprice = price
    def getproductprice(self):
        return self.productprice

class CardAccount():
    def __init__(self):
        self.cardid=""
        self.cardholdername=""
        self.cardamount=0
    def setCardamount(self ,carda=0):
        self.cardamount = carda
    def getCardamount(self):
        return self.cardamount

class Webuser:
    def __init__(self):
        self.username=""
        self.password=""
        self.fullname=""
        self.address=""
        self.telephone=""
        self.email=""
        self.Washcardnumber=0
        self.card = []

    def add_card(self, cardid, cardholdername):
            cards = CardAccount()
            cards.__setattr__("cardid", cardid)
            cards.__setattr__("cardholdername", cardholdername)
            self.cards.append(cards)




class RegularUser(Webuser):
    def __init__(self):
        Webuser.__init__(self)
        self.card = CardAccount()


    def user(self):
        window3 = tk.Toplevel()
        try:

            pagename = tk.Label(window3, text="USER REGISTRATION")
            pagename.pack()
            window3.title("Regular User Register")
            fullnametext = tk.Label(window3, text="Enter your Fullname")
            self.fullname = tk.Entry(window3)
            fullnametext.pack()
            self.fullname.pack()
            usertext = tk.Label(window3, text="Enter your username")
            self.username = tk.Entry(window3)
            usertext.pack()
            self.username.pack()
            passwordtext = tk.Label(window3, text="Enter your password")
            self.password = tk.Entry(window3)
            self.password.config(show="*")
            passwordtext.pack()
            self.password.pack()
            emailtext = tk.Label(window3, text="Enter your Email")
            self.email = tk.Entry(window3)
            emailtext.pack()
            self.email.pack()
            teletext = tk.Label(window3, text="Enter your Telephone number")
            self.telephone = tk.Entry(window3)
            teletext.pack()
            self.telephone.pack()
            addtext = tk.Label(window3, text="Enter your Address")
            self.Address = tk.Entry(window3)
            addtext.pack()
            self.Address.pack()
            membertext = tk.Label(window3,
                                  text="Enter your Membership type gold for gold membership Type silver for silver membership type regular for regular membership")
            self.Member = tk.Entry(window3)
            membertext.pack()
            self.Member.pack()
        except ValueError:
            raise ValueError("Enter a valid input")

        cardtext = tk.Label( window3,text="Your Assigned Card Digit number")
        self.cardnumber = tk.Entry(window3)
        v=random.randint(100000,999999)
        self.cardnumber.insert(tk.END, v)
        cardtext.pack()
        self.cardnumber.pack()


        self.button = tk.Button(window3,text="register", width=5, height=2, command=self.validate)
        self.button.pack()

    def validate(self):
        if ( self.username.get() == "" and self.password.get() == "" and  self.fullname.get()== "" and  self.email.get() =="" and self.Address.get() =="" ):
            messagebox.showinfo("" ,"Blank Not Allowed ")

        else:
            self.registerfile()

    def registerfile(self):
        window3 = tk.Toplevel()
        user = self.username.get()
        passw= self.password.get()
        addr = self.Address.get()
        email = self.email.get()
        card = self.cardnumber.get()
        tele = self.telephone.get()
        full= self.fullname.get()
        membe=self.Member.get()
        file = open("Web_user", "a")

        file.write(user)
        file.write(",")
        file.write(passw + "\n")
        file.close()
        file1 = open("records", "a")
        file1.write(user)
        file1.write(",")
        file1.write(passw)
        file1.write(",")
        file1.write(email)
        file1.write(",")
        file1.write(addr)
        file1.write(",")
        file1.write(card)
        file1.write(",")
        file1.write(tele)
        file1.write(",")
        file1.write(full)
        file1.write(",")
        file1.write(membe)
        file1.write(",")
        file1.write("\n")
        file1.close()

        card=0
        pur=0

        file2 = open("washcardrecord", "a")
        file2.write(user)
        file2.write(",")
        file2.write(str(card))
        file2.write(",")
        file2.write(str(pur))
        file2.write(",")
        file2.write("\n")
        file2.close()

        self.username.delete(0, tk.END)
        self.password.delete(0, tk.END)
        self.cardnumber.delete(0, tk.END)
        self.email.delete(0, tk.END)
        self.Address.delete(0, tk.END)
        self.telephone.delete(0, tk.END)
        self.fullname.delete(0, tk.END)
        self.Member.delete(0, tk.END)

        self.success = tk.Label( window3,text="You have successfully registered", fg="green")
        self.success.pack()

    def userlogin(self):
        window7= tk.Toplevel()
        usertext = tk.Label(window7, text="Enter your username")
        self.username = tk.Entry(window7)
        usertext.pack()
        self.username.pack()
        passwordtext = tk.Label(window7, text="Enter your password")
        self.password = tk.Entry(window7)
        self.password.config(show="*")
        passwordtext.pack()
        self.password.pack()
        self.button = tk.Button(window7, text="login", width=5, height=2, command=self.validatelogin)
        self.button.pack()
    def validatelogin(self):

        with open('Web_user', 'r') as file:
            user = self.username.get()
            passw = self.password.get()

            if ((user + "," + passw + "\n") in file.readlines()):

                self.logedin()
            else:
                messagebox.showinfo("",
                                    "Log in failed ,Username or Password is wrong ")

    def logedin(self):
        window9 = tk.Toplevel()
        userbutt= tk.Button(window9, text="Check your Details", width=25, height=2, command=self.detail)
        userbutt.pack()
        userbut = tk.Button(window9, text="Purchase Products", width=25, height=2,command=self.purchase)
        userbut.pack()

        empbut = tk.Button(window9, text="TopUp Card", width=25, height=2 ,command=self.pluscard)

        empbut.pack()
    def detail(self):
        windoww = tk.Toplevel()
        user = self.username.get()
        file=open("records","r")
        for line in file:
            currentline = line.split(",")
            if user == currentline[0]:
                    username=currentline[0]
                    password = currentline[1]
                    email=currentline[2]
                    address = currentline[3]
                    card=currentline[4]
                    tele=currentline[5]
                    fullname=currentline[6]
                    membership=currentline[7]

                    yourinfo = tk.Label(windoww,text="Username " + username + "\n"
                        + "Password  " + password + "\n"+ "Email  "+ email + "\n"
                                           + "Address " + address + "\n" + "Card number "  +   card + "\n"+  "Telephone number " +  tele +"\n"+  "Full Name " + fullname
                                        +"\n"+  "Membership " + membership)

                    yourinfo.pack()

    def pluscard(self):
        windowp = tk.Toplevel()
        def topupcash():
            windowp = tk.Toplevel()
            cashinfo = tk.Label(windowp,
                                text="You can Find the ATM Machine at the right corner of the building to top up using Cash")
            cashinfo.pack()


        userbut = tk.Button(windowp, text="TopUp using Card", width=25, height=2 ,command=self.topupcard)
        userbut.pack()
        empbut = tk.Button(windowp, text="TopUp using Cash ", width=25, height=2 ,command=topupcash)
        empbut.pack()
    def topupcard(self):
        windows=tk.Toplevel()

        try:
            useramount = tk.Label(windows, text="How much do you want to top up")
            self.Amount = tk.Entry(windows)
            useramount.pack()
            self.Amount.pack()
        except ValueError:
            raise ValueError("Enter a valid input")

        empbut = tk.Button(windows, text="TopUp ", width=25, height=2, command=self.totall)
        empbut.pack()
    def totall(self):
        windows1 = tk.Toplevel()
        user = self.username.get()
        file = open("records", "r")
        for line in file:
            currentline = line.split(",")
            if user == currentline[0]:
                cardnum = currentline[4]
        wash = open("washcardrecord", "r")
        for line in reversed(wash.readlines()):
            currentline = line.split(",")
            if user == currentline[0]:
                total = float(currentline[1])
                break


        total =total+int(self.Amount.get())
        totalamount = tk.Label(windows1, text="your total Amount in your card with card number " + str(cardnum) +" is " + str(total))
        totalamount.pack()
        self.card.setCardamount(total)
        total = self.card.getCardamount()
        print(total)

    def purchase(self):
        windo = tk.Toplevel()
        try:
            membertext = tk.Label(windo,
                                  text="type 1 if you have gold member 2 if you have silver member 3 if you are a regular member")
            membertext.pack()
            self.Member = tk.Entry(windo)
            self.Member.pack()
        except ValueError:
            raise ValueError("Enter a valid input")
        proinfo = tk.Label(windo, text="Choose Car products to proceed with")
        proinfo.pack()
        pro1 = tk.Button(windo, text="Regular Wash", width=25, height=2, command=self.Wash)
        pro1.pack()
        pro2 = tk.Button(windo, text="Car Steam Cleaning ", width=25, height=2, command=self.Steam)
        pro2.pack()
        pro3 = tk.Button(windo, text="Car Detailing  ", width=25, height=2, command=self.Detailing)
        pro3.pack()
        pro4= tk.Button(windo, text="Car Polish", width=25, height=2, command=self.Polish)
        pro4.pack()
        pro5 = tk.Button(windo, text="Car Wax ", width=25, height=2, command=self.Wax)
        pro5.pack()
    def Wash(self,pro=products()):
        pro.setproductid("1")
        pro.setproductname("Wash Car")
        pro.setproductprice(25)
        id=pro.getproductid()
        productname=pro.getproductname()
        productprice=pro.getproductprice()
        self.price=pro.getproductprice()
        wind= tk.Toplevel()
        Washtext = tk.Label(wind,
                              text="This is Wash Car service ,The price for a quantity is " + str(self.price) + " Enter the quantity in number to proceed ")
        Washtext.pack()
        self.quantity = tk.Entry(wind)
        self.quantity.pack()
        buy = tk.Button(wind, text="Purchase", width=25, height=2, command=self.buy)
        buy.pack()
        user = self.username.get()
        file = open("Products&prices", "a")
        file.write(user)
        file.write(",")
        file.write(id)
        file.write(",")
        file.write(productname)
        file.write(",")
        file.write(str(productprice )+ "\n")
        file.close()

    def Steam(self, pro=products()):
        pro.setproductid("2")
        pro.setproductname("Steam Car")
        pro.setproductprice(34)
        id = pro.getproductid()
        productname = pro.getproductname()
        productprice = pro.getproductprice()
        self.price = pro.getproductprice()
        wind = tk.Toplevel()
        steamtext = tk.Label(wind,
                            text="This is Steam Car service ,The price for a quantity is " + str(
                                self.price) + " Enter the quantity in number to proceed ")
        steamtext.pack()
        self.quantity = tk.Entry(wind)
        self.quantity.pack()
        buy = tk.Button(wind, text="Purchase", width=25, height=2, command=self.buy)
        buy.pack()
        user = self.username.get()
        file = open("Products&prices", "a")
        file.write(user)
        file.write(",")
        file.write(id)
        file.write(",")
        file.write(productname)
        file.write(",")
        file.write(str(productprice) + "\n")
        file.close()

    def Detailing(self, pro=products()):
        pro.setproductid("3")
        pro.setproductname("Detailing Car")
        pro.setproductprice(54)
        id = pro.getproductid()
        productname = pro.getproductname()
        productprice = pro.getproductprice()
        self.price = pro.getproductprice()
        wind = tk.Toplevel()
        Washtext = tk.Label(wind,
                            text="This is Wash Car service ,The price for a quantity is " + str(
                                self.price) + "Enter the quantity in number to proceed ")
        Washtext.pack()
        self.quantity = tk.Entry(wind)
        self.quantity.pack()
        buy = tk.Button(wind, text="Purchase", width=25, height=2, command=self.buy)
        buy.pack()
        user = self.username.get()
        file = open("Products&prices", "a")
        file.write(user)
        file.write(",")
        file.write(id)
        file.write(",")
        file.write(productname)
        file.write(",")
        file.write(str(productprice) + "\n")
        file.close()

    def Polish(self, pro=products()):
        pro.setproductid("4")
        pro.setproductname("Polish Car")
        pro.setproductprice(37)
        id = pro.getproductid()
        productname = pro.getproductname()
        productprice = pro.getproductprice()
        self.price = pro.getproductprice()
        wind = tk.Toplevel()
        Washtext = tk.Label(wind,
                            text="This is Wash Car service ,The price for a quantity is " + str(
                                self.price) + "Enter the quantity in number to proceed ")
        Washtext.pack()
        self.quantity = tk.Entry(wind)
        self.quantity.pack()
        buy = tk.Button(wind, text="Purchase", width=25, height=2, command=self.buy)
        buy.pack()
        user = self.username.get()
        file = open("Products&prices", "a")
        file.write(user)
        file.write(",")
        file.write(id)
        file.write(",")
        file.write(productname)
        file.write(",")
        file.write(str(productprice) + "\n")
        file.close()

    def Wax(self, pro=products()):
        pro.setproductid("5")
        pro.setproductname("Wax Car")
        pro.setproductprice(48)
        id = pro.getproductid()
        productname = pro.getproductname()
        productprice = pro.getproductprice()
        self.price = pro.getproductprice()
        wind = tk.Toplevel()
        Washtext = tk.Label(wind,
                            text="This is Wash Car service ,The price for a quantity is " + str(
                                self.price) + " Enter the quantity in number to proceed ")
        Washtext.pack()
        self.quantity = tk.Entry(wind)
        self.quantity.pack()
        buy = tk.Button(wind, text="Purchase", width=25, height=2, command=self.buy)
        buy.pack()
        user = self.username.get()
        file = open("Products&prices", "a")
        file.write(user)
        file.write(",")
        file.write(id)
        file.write(",")
        file.write(productname)
        file.write(",")
        file.write(str(productprice) + "\n")
        file.close()

    def buy(self):
        wind1 = tk.Toplevel()
        sum= int(self.quantity.get()) * int(self.price)
        discount = int(self.Member.get())
        if discount == 1 :
            sum_pay=sum -(sum*0.35)
        elif discount == 2:
            sum_pay = sum - (sum * 0.25)
        else:
            sum_pay = sum - (sum * 0.15)
        total = self.card.getCardamount()
        total= total - sum_pay
        self.card.setCardamount(total)

        buytext = tk.Label(wind1,
                            text="The total amount with discount is  " + str(sum_pay))
        buytext.pack()
        user = self.username.get()
        total = self.card.getCardamount()
        file = open("washcardrecord", "a")
        file.write(user)
        file.write(",")
        file.write(str(total))
        file.write(",")
        file.write(str(sum_pay) + "\n")
        file.close()
        buy = tk.Button(wind1, text="view all profit", width=25, height=2, command=self.profit)
        buy.pack()







class Employee(Webuser):
    def __init__(self):
        Webuser.__init__(self)
        self.card = CardAccount()


    def emp(self):
        window4 = tk.Toplevel()
        try:
            fullnametext = tk.Label(window4, text="Enter your Fullname")
            self.fullname = tk.Entry(window4)
            fullnametext.pack()
            self.fullname.pack()
            empidtext = tk.Label(window4, text="Enter your employeeid")
            self.empid = tk.Entry(window4)
            empidtext.pack()
            self.empid.pack()
            usertext = tk.Label(window4, text="Enter your username")
            self.username = tk.Entry(window4)
            usertext.pack()
            self.username.pack()
            passwordtext = tk.Label(window4, text="Enter your password")
            self.password = tk.Entry(window4)
            self.password.config(show="*")
            passwordtext.pack()
            self.password.pack()
            emailtext = tk.Label(window4, text="Enter your Email")
            self.email = tk.Entry(window4)
            emailtext.pack()
            self.email.pack()
            teletext = tk.Label(window4, text="Enter your Telephone number")
            self.telephone = tk.Entry(window4)
            teletext.pack()
            self.telephone.pack()
            addtext = tk.Label(window4, text="Enter your Address")
            self.Address = tk.Entry(window4)
            addtext.pack()
            self.Address.pack()
            cardtext = tk.Label(window4, text="Your Assigned Card Digit number")
            self.cardnumber = tk.Entry(window4)
            v = random.randint(100000, 999999)
            self.cardnumber.insert(tk.END, v)
            cardtext.pack()
            self.cardnumber.pack()
            self.Reguemp = tk.Radiobutton(window4, text="Regular Employee", value=1)
            self.Reguemp.pack()
            self.manager = tk.Radiobutton(window4, text="Manager", value=2)
            self.manager.pack()
        except ValueError:
            raise ValueError("Enter a valid input")


        self.button = tk.Button(window4,text="register", width=5, height=2, command=self.validate)
        self.button.pack()
    def validate(self):
        if ( self.username.get() == "" and self.password.get() == "" and  self.fullname.get()== "" and  self.email.get() =="" and self.Address.get() =="" ):
            messagebox.showinfo("" ,"Blank Not Allowed ")

        else:
            self.registeremp()
    def registeremp(self):

        if len(self.empid.get()) == 0:

            messagebox.showinfo("", "Please enter your employee id if you have one else register as a regular user ")
        else:
            self.registerfile()
    def registerfile(self):
        window4 = tk.Toplevel()
        user = self.username.get()
        passw= self.password.get()
        addr=self.Address.get()
        email=self.email.get()
        card=self.cardnumber.get()
        tele=self.telephone.get()
        full=self.fullname.get()
        membe=self.empid.get()



        file = open("Web_user", "a")

        file.write(user)
        file.write(",")
        file.write(passw)
        file.write("\n")
        file.close()
        file1 = open("records", "a")
        file1.write(user)
        file1.write(",")
        file1.write(passw)
        file1.write(",")
        file1.write(email)
        file1.write(",")
        file1.write(addr)
        file1.write(",")
        file1.write(card)
        file1.write(",")
        file1.write(tele)
        file1.write(",")
        file1.write(full)
        file1.write(",")
        file1.write(membe)
        file1.write(",")
        file1.write("\n")
        file1.close()

        card = 0
        pur = 0

        file2 = open("washcardrecord", "a")
        file2.write(user)
        file2.write(",")
        file2.write(str(card))
        file2.write(",")
        file2.write(str(pur))
        file2.write(",")
        file2.write("\n")
        file2.close()







        self.empid.delete(0, tk.END)
        self.username.delete(0, tk.END)
        self.password.delete(0, tk.END)
        self.cardnumber.delete(0, tk.END)
        self.email.delete(0, tk.END)
        self.Address.delete(0, tk.END)
        self.telephone.delete(0, tk.END)

        self.success = tk.Label(window4,text="You have successfully registered", fg="green")
        self.success.pack()

    def emplogin(self):
        window6= tk.Toplevel()
        try:
            usertext = tk.Label(window6, text="Enter your username")
            self.username = tk.Entry(window6)
            usertext.pack()
            self.username.pack()
            passwordtext = tk.Label(window6, text="Enter your password")
            self.password = tk.Entry(window6)
            self.password.config(show="*")
            passwordtext.pack()
            self.password.pack()
            self.button = tk.Button(window6, text="login", width=5, height=2, command=self.validatelogin)
            self.button.pack()
        except ValueError:
            raise ValueError ("Enter a valid input")
    def validatelogin(self):

        with open('Web_user', 'r') as file:
            user = self.username.get()
            passw = self.password.get()

            if ((user + "," + passw + "\n") in file.readlines()):
                self.emporman()
            else:
                messagebox.showinfo("",
                                    "Log in failed ,Username or Password is wrong ")
    def emporman(self):
        mywin = tk.Toplevel()
        userbutt = tk.Button(mywin, text="Employee", width=25, height=2, command=self.logedin)
        userbutt.pack()
        userbut = tk.Button(mywin, text="Manager", width=25, height=2, command=self.manlogedin)
        userbut.pack()

    def logedin(self):
        window9 = tk.Toplevel()
        userbutt= tk.Button(window9, text="Check your Details", width=25, height=2, command=self.detail)
        userbutt.pack()
        userbut = tk.Button(window9, text="Purchase Products", width=25, height=2,command=self.purchase)
        userbut.pack()

        empbut = tk.Button(window9, text="TopUp Card", width=25, height=2 ,command=self.pluscard)

        empbut.pack()

    def manlogedin(self):
        window9 = tk.Toplevel()
        userbutt = tk.Button(window9, text="Check your Details", width=25, height=2, command=self.detail)
        userbutt.pack()
        userbut = tk.Button(window9, text="Purchase Products", width=25, height=2, command=self.purchase)
        userbut.pack()

        empbut = tk.Button(window9, text="TopUp Card", width=25, height=2, command=self.pluscard)

        empbut.pack()

        userbutt = tk.Button(window9, text="View Records", width=25, height=2, command=self.view)
        userbutt.pack()
        userbut = tk.Button(window9, text="Delete All Record", width=25, height=2, command=self.delete)
        userbut.pack()

        empbut = tk.Button(window9, text="View All Profit", width=25, height=2, command=self.profit)

        empbut.pack()
    def view(self):
        windowna = tk.Toplevel()
        empbut = tk.Button(windowna, text="View all members", width=25, height=2, command=self.members)

        empbut.pack()

        userbutt = tk.Button(windowna, text="List Employees", width=25, height=2, command=self.listemp)
        userbutt.pack()
        userbut = tk.Button(windowna, text="list Gold members", width=25, height=2, command=self.Goldmem)
        userbut.pack()

        empbut = tk.Button(windowna, text="List Silver members", width=25, height=2, command=self.Silvermem)

        empbut.pack()
        empbut = tk.Button(windowna, text="List Regular members", width=25, height=2, command=self.Regumem)

        empbut.pack()
    def listemp(self):
        window44 = tk.Toplevel()
        list=[]
        file = open("records", "r")
        for line in file:
            currentline = line.split(",")
            item =  currentline[7]
            if (item != "gold" and  item!= "silver" and item != "regular"):
                list.append(currentline[0])
            else:
                continue
        list.sort()
        self.success = tk.Label(window44, text=list)
        self.success.pack()

    def Goldmem(self):
        window44 = tk.Toplevel()
        list = []
        file = open("records", "r")
        for line in file:
            currentline = line.split(",")
            item = currentline[7]
            if (item == "gold"):
                list.append(currentline[0])

        list.sort()
        self.success = tk.Label(window44, text=list)
        self.success.pack()
    def  Silvermem(self):
        window44 = tk.Toplevel()
        list = []
        file = open("records", "r")
        for line in file:
            currentline = line.split(",")
            item = currentline[7]
            if (item == "silver"):
                list.append(currentline[0])
            else:
                continue
        list.sort()
        self.success = tk.Label(window44, text=list)
        self.success.pack()
    def Regumem(self):
        window44 = tk.Toplevel()
        list = []
        file = open("records", "r")
        for line in file:
            currentline = line.split(",")
            item = currentline[7]
            if (item == "regular"):
                list.append(currentline[0])
            else:
                continue
        list.sort()
        self.success = tk.Label(window44, text=list)
        self.success.pack()
    def members(self):
        window44 = tk.Toplevel()
        list = []
        file = open("records", "r")
        for line in file:
            currentline = line.split(",")


            list.append(currentline[0])

        list.sort()
        self.success = tk.Label(window44, text=list)
        self.success.pack()

    def delete(self):
        file = open("records", "r+")
        file.truncate(0)
        file.close()

    def detail(self):
        windoww = tk.Toplevel()
        user = self.username.get()
        file=open("records","r")
        for line in file:
            currentline = line.split(",")
            if user == currentline[0]:
                    username=currentline[0]
                    password = currentline[1]
                    email=currentline[2]
                    address = currentline[3]
                    card=currentline[4]
                    tele=currentline[5]
                    fullname=currentline[6]
                    yourinfo = tk.Label(windoww,text="Username " + username + "\n"
                        + "password " + password + "\n"+ "Email "+ email + "\n"
                                           + "Address " + address + "\n" + "Card "  +   card + "\n"+  "Telephone number " +  tele +"\n"+  "Full Name " + fullname )

                    yourinfo.pack()

    def pluscard(self):
        windowp = tk.Toplevel()
        def topupcash():
            windowp = tk.Toplevel()
            cashinfo = tk.Label(windowp,
                                text="You can Find the ATM Machine at the right corner of the building to top up using Cash")
            cashinfo.pack()


        userbut = tk.Button(windowp, text="TopUp using Card", width=25, height=2 ,command=self.topupcard)
        userbut.pack()
        empbut = tk.Button(windowp, text="TopUp using Cash ", width=25, height=2 ,command=topupcash)
        empbut.pack()
    def topupcard(self):
        windows=tk.Toplevel()


        useramount = tk.Label(windows, text="How much do you want to top up")
        try:
            self.Amount = tk.Entry(windows)
            useramount.pack()
            self.Amount.pack()
        except ValueError:
            raise ValueError ("Enter a valid input")
        empbut = tk.Button(windows, text="TopUp ", width=25, height=2, command=self.totall)
        empbut.pack()
    def totall(self):
        windows1 = tk.Toplevel()
        user = self.username.get()
        file = open("records", "r")
        for line in file:
            currentline = line.split(",")
            if user == currentline[0]:
                cardnum = currentline[4]
        wash = open("washcardrecord", "r")
        for line in reversed(wash.readlines()):
            currentline = line.split(",")
            if user == currentline[0]:
                total = float(currentline[1])
                break
        self.card.setCardamount(total)
        total=self.card.getCardamount()
        print(total)
        total =total+int(self.Amount.get())
        totalamount = tk.Label(windows1, text="your total Amount in your card with card number " + str(cardnum) +" is " + str(total))
        totalamount.pack()
        self.card.setCardamount(total)
        total = self.card.getCardamount()
        print(total)

    def purchase(self):
        windo = tk.Toplevel()
        membertext = tk.Label(windo,
                              text="type 1 if you are a manager else type 2 an Employee")
        membertext.pack()
        self.Member = tk.Entry(windo)
        self.Member.pack()
        proinfo = tk.Label(windo, text="Choose Car products to proceed with")
        proinfo.pack()
        pro1 = tk.Button(windo, text="Regular Wash", width=25, height=2, command=self.Wash)
        pro1.pack()
        pro2 = tk.Button(windo, text="Car Steam Cleaning ", width=25, height=2, command=self.Steam)
        pro2.pack()
        pro3 = tk.Button(windo, text="Car Detailing  ", width=25, height=2, command=self.Detailing)
        pro3.pack()
        pro4= tk.Button(windo, text="Car Polish", width=25, height=2, command=self.Polish)
        pro4.pack()
        pro5 = tk.Button(windo, text="Car Wax ", width=25, height=2, command=self.Wax)
        pro5.pack()
    def Wash(self,pro=products()):
        pro.setproductid("1")
        pro.setproductname("Wash Car")
        pro.setproductprice(25)
        id=pro.getproductid()
        productname=pro.getproductname()
        productprice=pro.getproductprice()
        self.price=pro.getproductprice()
        wind= tk.Toplevel()
        Washtext = tk.Label(wind,
                              text="This is Wash Car service ,The price for a quantity is " + str(self.price) + " Enter the quantity in number to proceed ")
        Washtext.pack()
        self.quantity = tk.Entry(wind)
        self.quantity.pack()
        buy = tk.Button(wind, text="Purchase", width=25, height=2, command=self.buy)
        buy.pack()
        user = self.username.get()
        file = open("Products&prices", "a")
        file.write(user)
        file.write(",")
        file.write(id)
        file.write(",")
        file.write(productname)
        file.write(",")
        file.write(str(productprice )+ "\n")
        file.close()

    def Steam(self, pro=products()):
        pro.setproductid("2")
        pro.setproductname("Steam Car")
        pro.setproductprice(34)
        id = pro.getproductid()
        productname = pro.getproductname()
        productprice = pro.getproductprice()
        self.price = pro.getproductprice()
        wind = tk.Toplevel()
        steamtext = tk.Label(wind,
                            text="This is Steam Car service ,The price for a quantity is " + str(
                                self.price) + " Enter the quantity in number to proceed ")
        steamtext.pack()
        self.quantity = tk.Entry(wind)
        self.quantity.pack()
        buy = tk.Button(wind, text="Purchase", width=25, height=2, command=self.buy)
        buy.pack()
        user = self.username.get()
        file = open("Products&prices", "a")
        file.write(user)
        file.write(",")
        file.write(id)
        file.write(",")
        file.write(productname)
        file.write(",")
        file.write(str(productprice) + "\n")
        file.close()

    def Detailing(self, pro=products()):
        pro.setproductid("3")
        pro.setproductname("Detailing Car")
        pro.setproductprice(54)
        id = pro.getproductid()
        productname = pro.getproductname()
        productprice = pro.getproductprice()
        self.price = pro.getproductprice()
        wind = tk.Toplevel()
        Washtext = tk.Label(wind,
                            text="This is Wash Car service ,The price for a quantity is " + str(
                                self.price) + "Enter the quantity in number to proceed ")
        Washtext.pack()
        self.quantity = tk.Entry(wind)
        self.quantity.pack()
        buy = tk.Button(wind, text="Purchase", width=25, height=2, command=self.buy)
        buy.pack()
        user = self.username.get()
        file = open("Products&prices", "a")
        file.write(user)
        file.write(",")
        file.write(id)
        file.write(",")
        file.write(productname)
        file.write(",")
        file.write(str(productprice) + "\n")
        file.close()

    def Polish(self, pro=products()):
        pro.setproductid("4")
        pro.setproductname("Polish Car")
        pro.setproductprice(37)
        id = pro.getproductid()
        productname = pro.getproductname()
        productprice = pro.getproductprice()
        self.price = pro.getproductprice()
        wind = tk.Toplevel()
        Washtext = tk.Label(wind,
                            text="This is Wash Car service ,The price for a quantity is " + str(
                                self.price) + "Enter the quantity in number to proceed ")
        Washtext.pack()
        self.quantity = tk.Entry(wind)
        self.quantity.pack()
        buy = tk.Button(wind, text="Purchase", width=25, height=2, command=self.buy)
        buy.pack()
        user = self.username.get()
        file = open("Products&prices", "a")
        file.write(user)
        file.write(",")
        file.write(id)
        file.write(",")
        file.write(productname)
        file.write(",")
        file.write(str(productprice) + "\n")
        file.close()

    def Wax(self, pro=products()):
        pro.setproductid("5")
        pro.setproductname("Wax Car")
        pro.setproductprice(48)
        id = pro.getproductid()
        productname = pro.getproductname()
        productprice = pro.getproductprice()
        self.price = pro.getproductprice()
        wind = tk.Toplevel()
        Washtext = tk.Label(wind,
                            text="This is Wash Car service ,The price for a quantity is " + str(
                                self.price) + " Enter the quantity in number to proceed ")
        Washtext.pack()
        self.quantity = tk.Entry(wind)
        self.quantity.pack()
        buy = tk.Button(wind, text="Purchase", width=25, height=2, command=self.buy)
        buy.pack()
        user = self.username.get()
        file = open("Products&prices", "a")
        file.write(user)
        file.write(",")
        file.write(id)
        file.write(",")
        file.write(productname)
        file.write(",")
        file.write(str(productprice) + "\n")
        file.close()

    def buy(self):
        wind1 = tk.Toplevel()
        sum= int(self.quantity.get()) * int(self.price)
        discount = int(self.Member.get())
        if discount == 1 :
            sum_pay=sum -(sum*0.45)

        else:
            sum_pay = sum - (sum * 0.40)
        total = self.card.getCardamount()
        total= total - sum_pay
        self.card.setCardamount(total)

        buytext = tk.Label(wind1,
                            text="The total amount with discount is  " + str(sum_pay))
        buytext.pack()
        user = self.username.get()
        total = self.card.getCardamount()
        file = open("washcardrecord", "a")
        file.write(user)
        file.write(",")
        file.write(str(total))
        file.write(",")
        file.write(str(sum_pay) + "\n")
        file.close()

    def profit(self):
        wind2 = tk.Toplevel()
        file = open("washcardrecord", "r")
        profit=0.0
        for line in file:

            currentline = line.split(",")

            profit = profit + float(currentline[2])
        buytext = tk.Label(wind2,
                           text="The total profit  " + str(profit))
        buytext.pack()




