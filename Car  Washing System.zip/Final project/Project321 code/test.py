import tkinter as tk
from FileManager import Webuser , RegularUser , Employee
global window
window=tk.Tk()

ob1=RegularUser()
ob2=Employee()
def register ():
    window1 =tk.Toplevel(window)
    userbut = tk.Button(window1,text="Regular User Register", width=25, height=2, command=ob1.user)
    userbut.pack()
    empbut = tk.Button(window1,text="Employee Register", width=25, height=2, command=ob2.emp)
    empbut.pack()


def login():
    window2 = tk.Toplevel(window)
    userbut = tk.Button(window2, text="Regular User Login", width=25, height=2, command=ob1.userlogin)
    userbut.pack()
    empbut = tk.Button(window2, text="Employee Login", width=25, height=2, command=ob2.emplogin)
    empbut.pack()

register=tk.Button(text="register", height="2", width="10",command=register )
login=tk.Button(text="Login", height="2", width="10",command=login )


register.pack()
login.pack()


window.mainloop()

