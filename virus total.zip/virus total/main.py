from tkinter import *
import tkinter as tk
from tkinter import *
import os
import requests
import json
import time
import json
import os
import pathlib
import shutil
from PIL import Image, ImageTk
from tkinter.ttk import *
from cryptography.fernet import Fernet

ur = 'https://www.virustotal.com/vtapi/v2/file/report'
url = 'https://www.virustotal.com/vtapi/v2/file/scan'
params = {'apikey': '9bced174764b7e24d6906368edc15f1f47e873e4e776db4d7afe7f3cdd15e387'}

keyy = 'FUAgD_8ehUxFg9XB-sWAfJINc-GrBKPxaMAKZ-qVe-g='
key = keyy.encode()

fer = Fernet(key)
parent_dir = "C:/Users/esiph/Documents/"
directory = "quarentine"
# Path
path = os.path.join(parent_dir, directory)
try:
    os.mkdir(path)
except:
    pass

root = Tk()
class frame:
    def __init__(self, master):
        self.master = master
        self.secondary_win = None
        self.third_win = None
        self.master.title('Welcome to VST Total Protection')
        self.master.geometry("300x450+10+20")
        self.master.configure(bg='#8B6969')
        style = Style()
        image1 = Image.open("C:/Users/esiph/Documents/pos/lo.PNG")
        rimage = image1.resize((120, 45))
        test = ImageTk.PhotoImage(rimage)
        label1 = tk.Label(image=test)
        label1.image = test
        label1.place(x=90, y=5)
        style.configure('W.TButton', font=
        ('calibri', 12, 'bold'),
                        foreground='#8B1A1A', bg='#4A4A4A', height=10, width=20)
        btnn = Button(self.master, text='Quick Scan', style = 'W.TButton',command=self.Scan)
        btnn.place(x=60, y=90)
        image2 = Image.open("C:/Users/esiph/Documents/pos/cap.PNG")
        rimage1 = image2.resize((120, 150))
        test = ImageTk.PhotoImage(rimage1)
        label2 = tk.Label(image=test)
        label2.image = test
        label2.place(x=90, y=170)


    def Scan(self):

        if not self.secondary_win:
            self.secondary_win = Toplevel()
            self.secondary_win.title('Welcome to VST Total Protection')
            self.secondary_win.geometry("300x450+10+20")
            self.secondary_win.configure(bg='#8B6969')

            back_btn = Button(self.secondary_win, text="Back", command=self.Backward)
            back_btn.place(x=5, y=400)
            self.master.withdraw()
            count =0
            for root, dirs, files in os.walk('C:/'):
                for file in files:
                    count = count + 1
                    filename = os.path.basename(file)
                    filepath = os.path.abspath(os.path.join(root, filename))
                    f = open("json.txt", "a")
                    f.write(filename)
                    f.write(",")
                    params = {'apikey': '9bced174764b7e24d6906368edc15f1f47e873e4e776db4d7afe7f3cdd15e387'}
                    try:
                      filess = {'file': (filename, open(filepath ,'rb').read())}

                      response = requests.post(url, files=filess, params=params)
                      print(response.json())
                      list = response.json()

                      print(response.status_code)
                      json_dump = (json.dumps(list))
                      json_load = json.loads(json_dump)

                      for x in json_load:
                        if x == "sha256":
                            f.write(str(json_load[x]) + "\n")
                            f.close()
                    except:
                        pass
            time.sleep(2)
            f = open("json.txt", "r")

            for line in f:
                currentline = line.split(",")
                filenm = currentline[0].rstrip()
                sha_26 = currentline[1].rstrip()
                ur = 'https://www.virustotal.com/vtapi/v2/file/report'
                params = {'apikey': '9bced174764b7e24d6906368edc15f1f47e873e4e776db4d7afe7f3cdd15e387', 'resource': sha_26}
                response = requests.get(ur, params=params)
                print(response.json())
                result = response.json()

                time.sleep(2)

                malware_found = result['positives']
                if  malware_found > 0 and  malware_found < 5:
                    file2 = open("Audit.txt", "a")
                    file2.write(filenm)
                    file2.write(",")
                    file2.write("suspiciuos" + "\n")
                    file2.close()
                    for root, dirs, files in os.walk('C:/'):
                        for name in files:
                            if name == filenm:
                                filepath = os.path.abspath(os.path.join(root, name))
                                with open(filepath, 'rb') as f:
                                    data = f.read()
                                    print(type(data))

                                with open(filepath, 'w') as f:
                                    f.write(fer.encrypt(data).decode())
                                    print('done')
                                nm = filenm
                                destination = 'C:/Users/esiph/Documents/quarentine/{}'.format(nm)

                                src_path = filepath
                                dst_path = os.path.join(destination)
                                shutil.move(src_path, dst_path)

                elif malware_found >= 5:
                    file2 = open("Audit.txt", "a")
                    file2.write(filenm)
                    file2.write(",")
                    file2.write("malicious" + "\n")

                    file2.close()

                    for root, dirs, files in os.walk('C:/Users/esiph/Documents'):
                        for name in files:

                            if name == filenm:
                                filepath = os.path.abspath(os.path.join(root, name))
                                os.remove(filepath)
            Audit = open("Audit.txt", "r")
            sus = 0
            mal = 0
            suslist = []
            mallist = []
            for line in Audit:
                currentline = line.split(",")
                p1 = currentline[0].rstrip()
                p = currentline[1].rstrip()

                if p == 'suspicious':
                    sus = sus + 1
                    suslist.append(p1)
                elif p == "malicious":
                    mal = mal + 1

                    mallist.append(p1)
            print(mal)
            susnm = str(sus)
            malnm = str(mal)

            malstr = ','.join([str(elem) for elem in mallist])
            susstr = ','.join([str(elem) for elem in suslist])
            if mal > 0 and sus > 0:
                res = (
                        str(count) + "files were analyzed \n" + malnm + " Malicious files were detected  \n and removed from your computer , \nthe List of  the malicious files\n detected is " + malstr
                )
                res = (
                        str(count) + " files were analyzed \n" + susnm + " Suspicious files were detected \n and are quarentined ,\n the List of the suspicious files \ndetected is " + susstr)
            elif mal > 0:
                res = (
                        str(count) + " files were analyzed \n" +  malnm + " Malicious files were detected \n and removed from your computer \n the List of  the malicious files\n detected is " + malstr)
            elif sus > 0:
                res = (
                        str(count) + " files were analyzed \n" + susnm + " Suspicious files were detected \n and are quarentined , the List of \n the suspicious files\n detected is " + susstr)
            else:
                res = ( str(count) + " files were analyzed \n" "No files were detected \n as malicious or suspicious")

            mee = tk.Label(self.secondary_win, text=res , width=26, height=8,
                           background=
             "gray71",foreground="black",font= ('Sans Serif', 11))


            mee.place(x=35, y=120)

            btnn = Button(self.secondary_win, text="Restore quarentined files", command=self.Restore)
            btnn.place(x=35 , y=300)

        else:
            self.secondary_win.deiconify()
            self.master.withdraw()

    def Restore(self):

        if not self.third_win:
            self.third_win = Toplevel()
            self.third_win.title('Welcome to VST Total Protection')
            self.third_win.geometry("300x450+10+20")
            self.third_win.configure(bg='#8B6969')
            back_btn = Button(self.third_win, text="Back", command=self.Back)
            back_btn.place(x=5, y=400)
            self.secondary_win.withdraw()
            path = 'C:/Users/esiph/Documents/quarentine/'
            dir = os.listdir(path)
            if len(dir) != 0:
                for root, dirs, files in os.walk('C:/Users/esiph/Documents/quarentine/'):

                    for filename in files:
                        filepath = os.path.join(root, filename)

                        with open(filepath, 'rb') as f:
                            data = f.read()

                        dec = fer.decrypt(data)
                        with open(filepath, 'wb') as dec_file:
                            dec_file.write(dec)
                            re='All files are unquarentined'
            else:
                re="No files to unquarentine"

            dis = tk.Label(self.third_win, text=re, width=26, height=8,background="gray71", foreground="black", font=('Sans Serif', 13))
            dis.place(x=35, y=120)
        else:
            self.third_win.deiconify()
            self.secondary_win.withdraw()

    def Backward(self):
        self.secondary_win.withdraw()
        self.master.deiconify()

    def Back(self):
        self.third_win.withdraw()
        self.secondary_win.deiconify()


temp = frame(root)

root.mainloop()


